
exports.related = function(req, res){
	res.set('Content-type','text/json');
	res.render('related', {post:req.param('Message')});
}

exports.view = function(req, res) {
	res.set('Content-type','text/json');
	setTimeout(function(){res.render('view',{id:req.params.id});},500);
	
}